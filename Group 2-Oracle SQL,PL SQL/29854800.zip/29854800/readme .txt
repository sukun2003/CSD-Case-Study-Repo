Manufacturing Quality Assurance System

1.created database schema for tables

a. qualitycheck
b. defects
c.qualityassurance report

2. added data or values to the created table

3.developed PLSQL procedures

a. mentioned the logic for insertion and updation of values as a procedure in quality checks.

b. mentioned the logic of how to create a procedure for updation and insertions and also market analysis, basic trends for defects

4. tests the procedure to call those procedures for defect.

5.used trigger to update the quality assurance table.
