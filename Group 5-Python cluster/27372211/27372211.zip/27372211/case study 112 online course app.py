import datetime

# Exception classes
class NotFoundError(Exception):
    pass

class AlreadyExistsError(Exception):
    pass

class CapacityError(Exception):
    pass

# Models
class Course:
    def __init__(self, course_id, title, description, instructor_id, capacity):
        self.course_id = course_id
        self.title = title
        self.description = description
        self.instructor_id = instructor_id
        self.capacity = capacity
        self.enrollments = 0

class Student:
    def __init__(self, student_id, name, email, address):
        self.student_id = student_id
        self.name = name
        self.email = email
        self.address = address

class Instructor:
    def __init__(self, instructor_id, name, email, expertise):
        self.instructor_id = instructor_id
        self.name = name
        self.email = email
        self.expertise = expertise

class Enrollment:
    def __init__(self, enrollment_id, student_id, course_id, enrollment_date):
        self.enrollment_id = enrollment_id
        self.student_id = student_id
        self.course_id = course_id
        self.enrollment_date = enrollment_date

# Management Classes
class CourseManagement:
    def __init__(self):
        self.courses = {}

    def add_course(self, course_id, title, description, instructor_id, capacity):
        if course_id in self.courses:
            raise AlreadyExistsError(f"Course with ID {course_id} already exists.")
        self.courses[course_id] = Course(course_id, title, description, instructor_id, capacity)

    def update_course(self, course_id, title=None, description=None, instructor_id=None, capacity=None):
        if course_id not in self.courses:
            raise NotFoundError(f"Course with ID {course_id} not found.")
        course = self.courses[course_id]
        if title: course.title = title
        if description: course.description = description
        if instructor_id: course.instructor_id = instructor_id
        if capacity: course.capacity = capacity

    def delete_course(self, course_id):
        if course_id not in self.courses:
            raise NotFoundError(f"Course with ID {course_id} not found.")
        del self.courses[course_id]

class StudentManagement:
    def __init__(self):
        self.students = {}

    def add_student(self, student_id, name, email, address):
        if student_id in self.students:
            raise AlreadyExistsError(f"Student with ID {student_id} already exists.")
        self.students[student_id] = Student(student_id, name, email, address)

    def update_student(self, student_id, name=None, email=None, address=None):
        if student_id not in self.students:
            raise NotFoundError(f"Student with ID {student_id} not found.")
        student = self.students[student_id]
        if name: student.name = name
        if email: student.email = email
        if address: student.address = address

    def delete_student(self, student_id):
        if student_id not in self.students:
            raise NotFoundError(f"Student with ID {student_id} not found.")
        del self.students[student_id]

class InstructorManagement:
    def __init__(self):
        self.instructors = {}

    def add_instructor(self, instructor_id, name, email, expertise):
        if instructor_id in self.instructors:
            raise AlreadyExistsError(f"Instructor with ID {instructor_id} already exists.")
        self.instructors[instructor_id] = Instructor(instructor_id, name, email, expertise)

    def update_instructor(self, instructor_id, name=None, email=None, expertise=None):
        if instructor_id not in self.instructors:
            raise NotFoundError(f"Instructor with ID {instructor_id} not found.")
        instructor = self.instructors[instructor_id]
        if name: instructor.name = name
        if email: instructor.email = email
        if expertise: instructor.expertise = expertise

    def delete_instructor(self, instructor_id):
        if instructor_id not in self.instructors:
            raise NotFoundError(f"Instructor with ID {instructor_id} not found.")
        del self.instructors[instructor_id]

class EnrollmentManagement:
    def __init__(self, course_management, student_management):
        self.enrollments = {}
        self.course_management = course_management
        self.student_management = student_management

    def enroll_student(self, enrollment_id, student_id, course_id):
        if enrollment_id in self.enrollments:
            raise AlreadyExistsError(f"Enrollment with ID {enrollment_id} already exists.")
        if course_id not in self.course_management.courses:
            raise NotFoundError(f"Course with ID {course_id} not found.")
        if student_id not in self.student_management.students:
            raise NotFoundError(f"Student with ID {student_id} not found.")
        course = self.course_management.courses[course_id]
        if course.enrollments >= course.capacity:
            raise CapacityError(f"Course with ID {course_id} is full.")
        enrollment_date = datetime.datetime.now()
        self.enrollments[enrollment_id] = Enrollment(enrollment_id, student_id, course_id, enrollment_date)
        course.enrollments += 1

    def update_enrollment(self, enrollment_id, student_id=None, course_id=None):
        if enrollment_id not in self.enrollments:
            raise NotFoundError(f"Enrollment with ID {enrollment_id} not found.")
        enrollment = self.enrollments[enrollment_id]
        if student_id: enrollment.student_id = student_id
        if course_id: enrollment.course_id = course_id

    def cancel_enrollment(self, enrollment_id):
        if enrollment_id not in self.enrollments:
            raise NotFoundError(f"Enrollment with ID {enrollment_id} not found.")
        enrollment = self.enrollments[enrollment_id]
        course = self.course_management.courses[enrollment.course_id]
        course.enrollments -= 1
        del self.enrollments[enrollment_id]

# Main Application
def main():
    course_mgmt = CourseManagement()
    student_mgmt = StudentManagement()
    instructor_mgmt = InstructorManagement()
    enrollment_mgmt = EnrollmentManagement(course_mgmt, student_mgmt)

    while True:
        print("\nOnline Learning Platform Management")
        print("1. Manage Courses")
        print("2. Manage Students")
        print("3. Manage Instructors")
        print("4. Manage Enrollments")
        print("5. Exit")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                print("\nCourse Management")
                print("1. Add Course")
                print("2. Update Course")
                print("3. Delete Course")
                course_choice = input("Enter your choice: ")

                if course_choice == '1':
                    course_id = input("Enter Course ID: ")
                    title = input("Enter Course Title: ")
                    description = input("Enter Course Description: ")
                    instructor_id = input("Enter Instructor ID: ")
                    capacity = int(input("Enter Course Capacity: "))
                    course_mgmt.add_course(course_id, title, description, instructor_id, capacity)
                    print("Course added successfully.")
                
                elif course_choice == '2':
                    course_id = input("Enter Course ID: ")
                    title = input("Enter new Course Title (leave blank to skip): ")
                    description = input("Enter new Course Description (leave blank to skip): ")
                    instructor_id = input("Enter new Instructor ID (leave blank to skip): ")
                    capacity = input("Enter new Course Capacity (leave blank to skip): ")
                    course_mgmt.update_course(course_id, title, description, instructor_id, int(capacity) if capacity else None)
                    print("Course updated successfully.")

                elif course_choice == '3':
                    course_id = input("Enter Course ID: ")
                    course_mgmt.delete_course(course_id)
                    print("Course deleted successfully.")

            elif choice == '2':
                print("\nStudent Management")
                print("1. Add Student")
                print("2. Update Student")
                print("3. Delete Student")
                student_choice = input("Enter your choice: ")

                if student_choice == '1':
                    student_id = input("Enter Student ID: ")
                    name = input("Enter Student Name: ")
                    email = input("Enter Student Email: ")
                    address = input("Enter Student Address: ")
                    student_mgmt.add_student(student_id, name, email, address)
                    print("Student added successfully.")

                elif student_choice == '2':
                    student_id = input("Enter Student ID: ")
                    name = input("Enter new Student Name (leave blank to skip): ")
                    email = input("Enter new Student Email (leave blank to skip): ")
                    address = input("Enter new Student Address (leave blank to skip): ")
                    student_mgmt.update_student(student_id, name, email, address)
                    print("Student updated successfully.")

                elif student_choice == '3':
                    student_id = input("Enter Student ID: ")
                    student_mgmt.delete_student(student_id)
                    print("Student deleted successfully.")

            elif choice == '3':
                print("\nInstructor Management")
                print("1. Add Instructor")
                print("2. Update Instructor")
                print("3. Delete Instructor")
                instructor_choice = input("Enter your choice: ")

                if instructor_choice == '1':
                    instructor_id = input("Enter Instructor ID: ")
                    name = input("Enter Instructor Name: ")
                    email = input("Enter Instructor Email: ")
                    expertise = input("Enter Instructor Expertise: ")
                    instructor_mgmt.add_instructor(instructor_id, name, email, expertise)
                    print("Instructor added successfully.")

                elif instructor_choice == '2':
                    instructor_id = input("Enter Instructor ID: ")
                    name = input("Enter new Instructor Name (leave blank to skip): ")
                    email = input("Enter new Instructor Email (leave blank to skip): ")
                    expertise = input("Enter new Instructor Expertise (leave blank to skip): ")
                    instructor_mgmt.update_instructor(instructor_id, name, email, expertise)
                    print("Instructor updated successfully.")

                elif instructor_choice == '3':
                    instructor_id = input("Enter Instructor ID: ")
                    instructor_mgmt.delete_instructor(instructor_id)
                    print("Instructor deleted successfully.")

            elif choice == '4':
                print("\nEnrollment Management")
                print("1. Enroll Student")
                print("2. Update Enrollment")
                print("3. Cancel Enrollment")
                enrollment_choice = input("Enter your choice: ")

                if enrollment_choice == '1':
                    enrollment_id = input("Enter Enrollment ID: ")
                    student_id = input("Enter Student ID: ")
                    course_id = input("Enter Course ID: ")
                    enrollment_mgmt.enroll_student(enrollment_id, student_id, course_id)
                    print("Student enrolled successfully.")

                elif enrollment_choice == '2':
                    enrollment_id = input("Enter Enrollment ID: ")
                    student_id = input("Enter new Student ID (leave blank to skip): ")
                    course_id = input("Enter new Course ID (leave blank to skip): ")
                    enrollment_mgmt.update_enrollment(enrollment_id, student_id, course_id)
                    print("Enrollment updated successfully.")

                elif enrollment_choice == '3':
                    enrollment_id = input("Enter Enrollment ID: ")
                    enrollment_mgmt.cancel_enrollment(enrollment_id)
                    print("Enrollment cancelled successfully.")

            elif choice == '5':
                print("Exiting the application.")
                break

            else:
                print("Invalid choice. Please try again.")

        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
