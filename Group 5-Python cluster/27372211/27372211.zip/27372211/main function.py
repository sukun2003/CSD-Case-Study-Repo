
def main():
    course_mgmt = CourseManagement()
    student_mgmt = StudentManagement()
    instructor_mgmt = InstructorManagement()
    enrollment_mgmt = EnrollmentManagement(course_mgmt, student_mgmt)

    while True:
        print("\nOnline Learning Platform Management")
        print("1. Manage Courses")
        print("2. Manage Students")
        print("3. Manage Instructors")
        print("4. Manage Enrollments")
        print("5. Exit")
        choice = input("Enter your choice: ")

        try:
            if choice == '1':
                print("\nCourse Management")
                print("1. Add Course")
                print("2. Update Course")
                print("3. Delete Course")
                course_choice = input("Enter your choice: ")

                if course_choice == '1':
                    course_id = input("Enter Course ID: ")
                    title = input("Enter Course Title: ")
                    description = input("Enter Course Description: ")
                    instructor_id = input("Enter Instructor ID: ")
                    capacity = int(input("Enter Course Capacity: "))
                    course_mgmt.add_course(course_id, title, description, instructor_id, capacity)
                    print("Course added successfully.")
                
                elif course_choice == '2':
                    course_id = input("Enter Course ID: ")
                    title = input("Enter new Course Title (leave blank to skip): ")
                    description = input("Enter new Course Description (leave blank to skip): ")
                    instructor_id = input("Enter new Instructor ID (leave blank to skip): ")
                    capacity = input("Enter new Course Capacity (leave blank to skip): ")
                    course_mgmt.update_course(course_id, title, description, instructor_id, int(capacity) if capacity else None)
                    print("Course updated successfully.")

                elif course_choice == '3':
                    course_id = input("Enter Course ID: ")
                    course_mgmt.delete_course(course_id)
                    print("Course deleted successfully.")

            elif choice == '2':
                print("\nStudent Management")
                print("1. Add Student")
                print("2. Update Student")
                print("3. Delete Student")
                student_choice = input("Enter your choice: ")

                if student_choice == '1':
                    student_id = input("Enter Student ID: ")
                    name = input("Enter Student Name: ")
                    email = input("Enter Student Email: ")
                    address = input("Enter Student Address: ")
                    student_mgmt.add_student(student_id, name, email, address)
                    print("Student added successfully.")

                elif student_choice == '2':
                    student_id = input("Enter Student ID: ")
                    name = input("Enter new Student Name (leave blank to skip): ")
                    email = input("Enter new Student Email (leave blank to skip): ")
                    address = input("Enter new Student Address (leave blank to skip): ")
                    student_mgmt.update_student(student_id, name, email, address)
                    print("Student updated successfully.")

                elif student_choice == '3':
                    student_id = input("Enter Student ID: ")
                    student_mgmt.delete_student(student_id)
                    print("Student deleted successfully.")

            elif choice == '3':
                print("\nInstructor Management")
                print("1. Add Instructor")
                print("2. Update Instructor")
                print("3. Delete Instructor")
                instructor_choice = input("Enter your choice: ")

                if instructor_choice == '1':
                    instructor_id = input("Enter Instructor ID: ")
                    name = input("Enter Instructor Name: ")
                    email = input("Enter Instructor Email: ")
                    expertise = input("Enter Instructor Expertise: ")
                    instructor_mgmt.add_instructor(instructor_id, name, email, expertise)
                    print("Instructor added successfully.")

                elif instructor_choice == '2':
                    instructor_id = input("Enter Instructor ID: ")
                    name = input("Enter new Instructor Name (leave blank to skip): ")
                    email = input("Enter new Instructor Email (leave blank to skip): ")
                    expertise = input("Enter new Instructor Expertise (leave blank to skip): ")
                    instructor_mgmt.update_instructor(instructor_id, name, email, expertise)
                    print("Instructor updated successfully.")

                elif instructor_choice == '3':
                    instructor_id = input("Enter Instructor ID: ")
                    instructor_mgmt.delete_instructor(instructor_id)
                    print("Instructor deleted successfully.")

            elif choice == '4':
                print("\nEnrollment Management")
                print("1. Enroll Student")
                print("2. Update Enrollment")
                print("3. Cancel Enrollment")
                enrollment_choice = input("Enter your choice: ")

                if enrollment_choice == '1':
                    enrollment_id = input("Enter Enrollment ID: ")
                    student_id = input("Enter Student ID: ")
                    course_id = input("Enter Course ID: ")
                    enrollment_mgmt.enroll_student(enrollment_id, student_id, course_id)
                    print("Student enrolled successfully.")

                elif enrollment_choice == '2':
                    enrollment_id = input("Enter Enrollment ID: ")
                    student_id = input("Enter new Student ID (leave blank to skip): ")
                    course_id = input("Enter new Course ID (leave blank to skip): ")
                    enrollment_mgmt.update_enrollment(enrollment_id, student_id, course_id)
                    print("Enrollment updated successfully.")

                elif enrollment_choice == '3':
                    enrollment_id = input("Enter Enrollment ID: ")
                    enrollment_mgmt.cancel_enrollment(enrollment_id)
                    print("Enrollment cancelled successfully.")

            elif choice == '5':
                print("Exiting the application.")
                break

            else:
                print("Invalid choice. Please try again.")

        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()
