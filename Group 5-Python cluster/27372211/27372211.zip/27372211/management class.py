class CourseManagement:
    def __init__(self):
        self.courses = {}

    def add_course(self, course_id, title, description, instructor_id, capacity):
        if course_id in self.courses:
            raise AlreadyExistsError(f"Course with ID {course_id} already exists.")
        self.courses[course_id] = Course(course_id, title, description, instructor_id, capacity)

    def update_course(self, course_id, title=None, description=None, instructor_id=None, capacity=None):
        if course_id not in self.courses:
            raise NotFoundError(f"Course with ID {course_id} not found.")
        course = self.courses[course_id]
        if title: course.title = title
        if description: course.description = description
        if instructor_id: course.instructor_id = instructor_id
        if capacity: course.capacity = capacity

    def delete_course(self, course_id):
        if course_id not in self.courses:
            raise NotFoundError(f"Course with ID {course_id} not found.")
        del self.courses[course_id]

class StudentManagement:
    def __init__(self):
        self.students = {}

    def add_student(self, student_id, name, email, address):
        if student_id in self.students:
            raise AlreadyExistsError(f"Student with ID {student_id} already exists.")
        self.students[student_id] = Student(student_id, name, email, address)

    def update_student(self, student_id, name=None, email=None, address=None):
        if student_id not in self.students:
            raise NotFoundError(f"Student with ID {student_id} not found.")
        student = self.students[student_id]
        if name: student.name = name
        if email: student.email = email
        if address: student.address = address

    def delete_student(self, student_id):
        if student_id not in self.students:
            raise NotFoundError(f"Student with ID {student_id} not found.")
        del self.students[student_id]

class InstructorManagement:
    def __init__(self):
        self.instructors = {}

    def add_instructor(self, instructor_id, name, email, expertise):
        if instructor_id in self.instructors:
            raise AlreadyExistsError(f"Instructor with ID {instructor_id} already exists.")
        self.instructors[instructor_id] = Instructor(instructor_id, name, email, expertise)

    def update_instructor(self, instructor_id, name=None, email=None, expertise=None):
        if instructor_id not in self.instructors:
            raise NotFoundError(f"Instructor with ID {instructor_id} not found.")
        instructor = self.instructors[instructor_id]
        if name: instructor.name = name
        if email: instructor.email = email
        if expertise: instructor.expertise = expertise

    def delete_instructor(self, instructor_id):
        if instructor_id not in self.instructors:
            raise NotFoundError(f"Instructor with ID {instructor_id} not found.")
        del self.instructors[instructor_id]

class EnrollmentManagement:
    def __init__(self, course_management, student_management):
        self.enrollments = {}
        self.course_management = course_management
        self.student_management = student_management

    def enroll_student(self, enrollment_id, student_id, course_id):
        if enrollment_id in self.enrollments:
            raise AlreadyExistsError(f"Enrollment with ID {enrollment_id} already exists.")
        if course_id not in self.course_management.courses:
            raise NotFoundError(f"Course with ID {course_id} not found.")
        if student_id not in self.student_management.students:
            raise NotFoundError(f"Student with ID {student_id} not found.")
        course = self.course_management.courses[course_id]
        if course.enrollments >= course.capacity:
            raise CapacityError(f"Course with ID {course_id} is full.")
        enrollment_date = datetime.datetime.now()
        self.enrollments[enrollment_id] = Enrollment(enrollment_id, student_id, course_id, enrollment_date)
        course.enrollments += 1

    def update_enrollment(self, enrollment_id, student_id=None, course_id=None):
        if enrollment_id not in self.enrollments:
            raise NotFoundError(f"Enrollment with ID {enrollment_id} not found.")
        enrollment = self.enrollments[enrollment_id]
        if student_id: enrollment.student_id = student_id
        if course_id: enrollment.course_id = course_id

    def cancel_enrollment(self, enrollment_id):
        if enrollment_id not in self.enrollments:
            raise NotFoundError(f"Enrollment with ID {enrollment_id} not found.")
        enrollment = self.enrollments[enrollment_id]
        course = self.course_management.courses[enrollment.course_id]
        course.enrollments -= 1
        del self.enrollments[enrollment_id]
